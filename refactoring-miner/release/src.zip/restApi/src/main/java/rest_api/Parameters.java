package rest_api;

public class Parameters {

    public static String repo = "";
    public static String commit1 = "";
    public static String commit2 = "";

    public Parameters(String repo, String commit1, String commit2 ) {
        this.repo = repo;
        this.commit1 = commit1;
        this.commit2 = commit2;
    }

    public String getRepo() {
        return repo;
    }
}