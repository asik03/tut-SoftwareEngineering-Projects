package rest_api;

import java.io.*; 
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ParametersController {

    //private static final String template = "Hello, %s!";
    //private final AtomicLong counter = new AtomicLong();

    @RequestMapping("/parameters")
    public String parameters(@RequestParam(value="repo", defaultValue="World") String repo, @RequestParam(value="commit1", defaultValue="") String commit1, @RequestParam(value="commit2", defaultValue="") String commit2) {
        if(Status.executing){
            return String.format("Already analyzing refactorings for repo %s", Parameters.repo);
        }
        //Analyze all commits
        if(commit1.length() == 0 || commit2.length() == 0){
            try{
                Status.ready = false;
                Status.executing = true;
                //Process pwd = Runtime.getRuntime().exec("pwd");
                Process process = Runtime.getRuntime().exec(String.format("/mine.sh %s", repo));
                new Parameters(repo, commit1, commit2);
                BufferedReader in = new BufferedReader(
                                new InputStreamReader(process.getInputStream()));
                String line = null;
                while ((line = in.readLine()) != null) {
                    System.out.println(line);
                }
                //Copy results to volume
                String filepath = "/mining_repo/all_refactorings.csv";
                String repoName = repo.substring(repo.lastIndexOf('/') + 1);
                Process process2 = Runtime.getRuntime().exec(String.format("cp %s /results/%s_all_refactorings.csv", filepath, repoName));

                Status.ready = true;
                Status.executing = false;
            } catch (Exception ex) {
                 ex.printStackTrace();
                 Status.executing = false;
            }

        //Analyze from beginCommit to endCommit
        }else {
            try{
                Status.ready = false;
                Status.executing = true;
                Process process = Runtime.getRuntime().exec(String.format("/mine.sh %s %s %s", repo, commit1, commit2));
                new Parameters(repo, commit1, commit2);
                BufferedReader in = new BufferedReader(
                                new InputStreamReader(process.getInputStream()));
                String line = null;
                while ((line = in.readLine()) != null) {
                    System.out.println(line);
                }
                //Copy results to volume
                String filepath =  String.format("/mining_repo/refactorings_%s_%s.csv", commit1, commit2);
                String repoName = repo.substring(repo.lastIndexOf('/') + 1);
                Process process2 = Runtime.getRuntime().exec(String.format("cp %s /results/%s_refactorings_%s_%s.csv", filepath, repoName, commit1, commit2));

                Status.ready = true;
                Status.executing = false;
            } catch (Exception ex) {
                 ex.printStackTrace();
                 Status.executing = false;
            }
        }

        //Return result to client
        

        return String.format("Analyzed Refactorings for repo %s", repo);

        //File file = new File("/mining_repo/1.txt"); //all_refactorings.csv    refactorings_startcommint_endcommit.csv
    }


}