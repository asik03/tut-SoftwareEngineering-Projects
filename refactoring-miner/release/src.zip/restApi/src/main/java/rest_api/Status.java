package rest_api;

public class Status {

    public static Boolean ready = false;
    public static Boolean executing = false;

}