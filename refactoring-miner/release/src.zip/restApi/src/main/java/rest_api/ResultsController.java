package rest_api;

import java.io.*; 
import java.nio.file.Files;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ResultsController {
    @RequestMapping("/results")
    public String results() {
        String filepath = "/mining_repo/all_refactorings.csv";
        if(Parameters.commit1.length() == 0 || Parameters.commit2.length() == 0){
            filepath = "/mining_repo/all_refactorings.csv";
        }
        else
        {
            filepath = String.format("/mining_repo/refactorings_%s_%s.csv", Parameters.commit1, Parameters.commit2);
        }

        File f = new File(filepath);

        if(Status.ready) {
            try{
                return new String(Files.readAllBytes(f.toPath()));
            }catch (Exception ex) {
                return "Error";
            }
        }else{
            return "Not ready";
        }
    }


}