package gr.uom.java.xmi;

public interface LocationInfoProvider {
	public LocationInfo getLocationInfo();
}
