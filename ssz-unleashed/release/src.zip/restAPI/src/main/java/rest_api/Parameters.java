package rest_api;

public class Parameters {

    public static String issueTracker = "";
    public static String repo = "";
    public static String commit1 = "";

    public Parameters(String issueTracker, String repo, String commit1) {
        this.issueTracker = issueTracker;
        this.repo = repo;
        this.commit1 = commit1;
    }

    public String getRepo() {
        return repo;
    }
}