package rest_api;

import java.io.*; 
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
//import org.apache.commons.io;

@RestController
public class CheckStatusController {
    @RequestMapping("/status")
    public String status() {
        if(Status.ready) {
            return "Results are ready";
        }else{
            return "Not ready";
        }
        
    }

    
}